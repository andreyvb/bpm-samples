update BPMSAMPLES_CONTRACT set NUMBER_ = '' where NUMBER_ is null ;
alter table BPMSAMPLES_CONTRACT alter column NUMBER_ set not null ;
