alter table BPMSAMPLES_TASK add column PROCESS_STATE varchar(255) ;
