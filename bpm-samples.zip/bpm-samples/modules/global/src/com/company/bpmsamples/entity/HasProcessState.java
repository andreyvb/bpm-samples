package com.company.bpmsamples.entity;

public interface HasProcessState {
    String getProcessState();
    void setProcessState(String processState);
}
