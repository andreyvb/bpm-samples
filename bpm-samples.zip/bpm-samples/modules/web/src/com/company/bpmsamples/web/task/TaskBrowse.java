package com.company.bpmsamples.web.task;

import com.haulmont.cuba.gui.components.AbstractLookup;

public class TaskBrowse extends AbstractLookup {
}