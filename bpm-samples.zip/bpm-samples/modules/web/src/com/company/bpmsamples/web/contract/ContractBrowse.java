package com.company.bpmsamples.web.contract;

import com.haulmont.cuba.gui.components.AbstractLookup;

public class ContractBrowse extends AbstractLookup {
}