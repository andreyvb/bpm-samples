# BPM Samples

## Overview

## How To Get Started With This Project

1. Import the project using the CUBA Studio
1. Run the project
1. Open the `BPM - Process Models` screen and upload model JSONs. Model JSONs are located under the [models](modules/core/web/WEB-INF/resources/models) directory.

## Samples

### Contract Approval Sample

The sample demonstrates how to use custom BPM forms.

Form XML descriptor: [start-contract-approval-form.xml](com/company/bpmsamples/web/forms/contract/start-contract-approval-form.xml)

Form Java controller: [StartContractApprovalForm.java](com/company/bpmsamples/web/forms/contract/StartContractApprovalForm.java)

BPM forms configuration file: [app-bpm-forms.xml](app-bpm-forms.xml)

Process model: `Contract approval - 1`

Application screen: `Application - Contracts` 

[editor XML descriptor](com/company/bpmsamples/web/contract/contract-edit.xml)

[editor Java controller](com.company.bpmsamples.web.contract.ContractEdit)

### Task Execution Sample